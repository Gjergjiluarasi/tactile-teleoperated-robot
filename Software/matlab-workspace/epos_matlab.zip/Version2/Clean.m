delete *.mexa64
delete *.mexa32
delete *.mexw32
delete *.mexw64
