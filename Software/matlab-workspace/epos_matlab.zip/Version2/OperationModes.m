classdef OperationModes
    enumeration 
        UnimplementedMode, HommingMode, CurrentMode, VelocityMode, PositionMode, ProfileVelocityMode, ProfilePositionMode
    end
end
