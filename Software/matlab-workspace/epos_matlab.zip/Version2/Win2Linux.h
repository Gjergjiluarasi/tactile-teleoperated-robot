#ifndef _WIN2LINUX_
#define _WIN2LINUX_
#define HANDLE void*
#define DWORD  unsigned int
#define WORD   unsigned short
#define BOOL   int
#define BYTE   unsigned char
#define TRUE   1
#define FALSE  0
#define HandleToLong (long)
#define LongToHandle (void*)
#define LONG   int
#define _inline 
#endif
